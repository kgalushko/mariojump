var canvas = document.getElementById("canvas"),
    ctx = canvas.getContext("2d"); //Canvas имеет метод getContext, который используется для получения контекста отображения. Контекст — это объект, вызывая методы которого, вы взаимодействуете с canvas API. 
var gLoop,
    points = 0,
    high = 0,
    state = 2, //2 - menu
    select = 0,
    win = false,
    soundJump = new Audio("sound/jump-small-cut.mp3"),
    soundJumpSuper = new Audio("sound/jump-super.wav"),
    soundCoin = new Audio("sound/coin.wav"),
    soundDie = new Audio("sound/die.wav"),
    soundKick = new Audio("sound/kick.wav"),
    soundPause = new Audio("sound/pause.wav"),
    music = new Audio("sound/music.mp3"),
    musicUnderground = new Audio("sound/underground.mp3");


window.onload = function () {
    WebFontConfig = {
        custom: {
            families: ['Press Start 2P'],
            urls: ['fonts.css']
        },
        active: function () {
            fontsReady = true;
            StartMenu();
        }
    };
    (function () {
        var wf = document.createElement('script');
        wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
            '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
        wf.type = 'text/javascript';
        wf.async = 'true';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(wf, s);
    })();
}

soundJump.volume = 0.7;

var width = window.innerWidth,
    height = window.innerHeight;

var background = '#6b8cff';

canvas.width = width;
canvas.height = height;

var clear = function () {
    ctx.fillStyle = background;
    ctx.beginPath();
    ctx.rect(0, 0, width, height);
    ctx.closePath();
    ctx.fill();
}

var stats = function() {
    this.image = new Image();
    this.image.src = "img/block2.png";
    ctx.fillStyle = ctx.createPattern(this.image, "repeat");
    ctx.fillRect(0, 0, canvas.width, 48);
    ctx.fillStyle = "#ffffff";
    ctx.textBaseline = "top"
    ctx.textAlign = "left";
    ctx.fillText("HIGH:", 10, 10);
    ctx.fillText(high, 10, 27);
    ctx.textAlign = "center";
    ctx.fillText("SCORE:", width/2, 10);
    ctx.fillText(points, width/2, 28);
    ctx.textAlign = "right";
    ctx.fillText("COINS:", width - 10, 10);
    ctx.fillText("00", width - 10, 28);
}

var player = new(function () {
    var that = this;

    this.image = new Image();
    this.image.src = "img/hero.png";

    this.width = 32;
    this.height = 32;

    this.X = 0;
    this.Y = 0;

    this.isJumping = 0;
    this.isFalling = 0;

    this.jumpSpeed = 0;
    this.fallSpeed = 0;

    this.isMoving = true;

    this.setPosition = function (x, y) {
        this.X = x;
        this.Y = y;
    }

    this.jump = function () {
        if (!this.isJumping && !this.isFalling) {
            this.fallSpeed = 0;
            this.isJumping = true;
            this.jumpSpeed = 24;
            soundJump.play();
        }
    }

    this.checkJump = function () {
        if (this.Y > height * 0.25) {
            this.setPosition(this.X, this.Y - this.jumpSpeed);
        } else {
            if (this.jumpSpeed > 10) {
                points += 1;
            }
            if (points > high) high = points;

            var rand = Math.random() * (width - platformWidth);


            platforms.forEach(function (platform, index) {
                platform.Y += that.jumpSpeed;
                if (platform.Y > height) {
                    platforms[index] = new Platform(rand, platform.Y - height - platformHeight);
                }
            });
            clouds.forEach(function (cloud, index) {
                cloud.Y += that.jumpSpeed / 5;
                if (cloud.Y > height) {
                    clouds[index] = new Cloud(Math.random() * (width - cloudWidth), Math.random() * (height - cloudHeight) - height - cloudHeight);
                }
            });
            mushrooms.forEach(function(mushroom, index){
                mushroom.Y += that.jumpSpeed / 5;
                if (mushroom.Y > height) {
                    clouds[index] = new Cloud(rand, mushroom.Y - height - mushroomHeight);
                }
            });

        }
        this.jumpSpeed--;
        if (this.jumpSpeed == 0) {
            this.isJumping = false;
            this.isFalling = true;
            this.fallSpeed = 1;
        }
    }

    this.checkFall = function () {
        if (this.Y < height - this.height) {
            this.setPosition(this.X, this.Y + this.fallSpeed);
            this.fallSpeed++;
        } else {
            if (points == 0) that.fallStop();
            GameOver();
        }
    }

    this.fallStop = function () {
        this.isFalling = false;
        this.fallSpeed = 0;
        this.jump();
    }

    this.moveLeft = function (theX) {
        if ((that.X > 0) && that.isMoving) {
            that.setPosition(theX - that.width / 2, that.Y);
        }
    }

    this.moveRight = function (theX) {
        if ((that.X + that.width < width) && that.isMoving) {
            that.setPosition(theX - that.width / 2, that.Y);
        }
    }

    this.draw = function () {
        try {
            ctx.drawImage(that.image, 0, 0, that.width, that.height,
                that.X, that.Y, that.width, that.height);
        } catch (e) {}
    }

    this.update = function () {
        if (this.isJumping) this.checkJump();
        if (this.isFalling) this.checkFall();
        this.draw();
    }

})();

var Cloud = function (x, y) {
    this.image = new Image();
    this.image.src = "img/cloud.png";

    this.width = 64;
    this.height = 48;

    this.isMoving = 1;
    this.direction = 1;

    this.draw = function () {
        try {
            ctx.drawImage(this.image, 0, 0, this.width, this.height, this.X, this.Y, this.width, this.height);
        } catch (e) {}
    }

    this.X = ~~x;
    this.Y = y;

    return this;
}

var Platform = function (x, y) {
    this.image = new Image();
    this.image.src = "img/block.png";

    this.width = 96;
    this.height = 32;

    this.onCollide = function () {
        player.fallStop();
    }

    this.isMoving = ~~(Math.random() * 2); //~~ Округляет число
    this.direction = ~~(Math.random() * 2) ? -1 : 1;

    this.draw = function () {
        try {
            ctx.drawImage(this.image, 0, 0, this.width, this.height, this.X, this.Y, this.width, this.height);
        } catch (e) {}
    }

    this.X = ~~x;
    this.Y = y;

    return this;
}

var Mushroom = function (x, y) {
    this.image = new Image();
    this.image.src = "img/mushroom.png";

    this.width = 32;
    this.height = 32;

    this.onCollide = function () {
        player.fallStop();
    }

    //this.isMoving = ~~(Math.random() * 2); //~~ Округляет число
    //this.direction = ~~(Math.random() * 2) ? -1 : 1;

    this.draw = function () {
        try {
            ctx.drawImage(this.image, 0, 0, this.width, this.height, this.X, this.Y, this.width, this.height);
        } catch (e) {}
    }

    this.X = ~~x;
    this.Y = y;

    return this;
}

var numberOfPlatforms = 6,
    platforms = [],
    platformWidth = 96,
    platformHeight = 32,
    numberOfClouds = 5,
    clouds = [],
    cloudWidth = 64,
    cloudHeight = 48,
    numberOfMushroom = 1,
    mushrooms = [],
    mushroomWidth = 32,
    mushroomHeight = 32;

var generateObjects = function () {
    var position = 0;
    var mushroomRandom = (Math.random() * (width - platformWidth));

    for (var i = 0; i < numberOfPlatforms; i++) {

        platforms[i] = new Platform(mushroomRandom, position);

        if (position < height - platformHeight) position += ~~(height / numberOfPlatforms);
    }

    for (var i = 0; i < numberOfClouds; i++) {
        clouds[i] = new Cloud((Math.random() * (width - cloudWidth)), (Math.random() * (height - cloudHeight)));
    }
    
    for (var i = 0; i < numberOfMushroom; i++) {

        mushrooms[i] = new Mushroom(mushroomRandom, position - platformHeight);

        if (position < height - mushroomHeight) position += ~~(height / numberOfMushroom);
    }
}();

var checkCollision = function () {
    platforms.forEach(function (e, index) {
        if ((player.isFalling) &&
            (player.X < e.X + platformWidth) &&
            (player.X + player.width > e.X) &&
            (player.Y + player.height > e.Y) &&
            (player.Y + player.height < e.Y + platformHeight)
        ) {
            e.onCollide();
        }
    });
}

var GameOver = function () {
    state = false;
    clearTimeout(gLoop);
    music.pause();
    if (points == high) {
        win = true;
    }
    setTimeout(function () {
        clear();
        ctx.textAlign = "center";
        ctx.textBaseline = "center"
        ctx.fillStyle = "#ffffff";
        if (win) ctx.fillText("NEW HIGH SCORE!", width / 2, height / 2);
        ctx.fillText("GAME OVER", width / 2, height / 2 - 60);
        ctx.fillText("YOUR RESULT:" + points, width / 2, height / 2 - 30);
    }, 100);
}

document.onmousemove = function (e) {
    if (state == 1) {
        if (player.X + canvas.offsetLeft > e.pageX - 20) {
            player.moveLeft(e.pageX - canvas.offsetLeft);
        } else if (player.X + canvas.offsetLeft < e.pageX - 20) {
            player.moveRight(e.pageX - canvas.offsetLeft);
        }
    } else {
        if (e.pageY - canvas.offsetTop < height / (2))
            select = 0;
        else select = 1;
    }
};

document.onmousedown = function (e) {
    if (state == false) {
        points = 0;
        state = 2;
        win = false;
        StartMenu();
    } else if (state == 2) {
        if (select == 0) {
            player.image.src = "img/hero.png";
            music.play();
        } else {
            window.close();
        }
        state = true;
    }
}

player.setPosition(~~((width - player.width) / 2), ~~((height - player.height) / 2));
player.jump();

var GameLoop = function () {
    clear();

    clouds.forEach(function (cloud, index) {
        if (cloud.isMoving == 1) {
            if (cloud.X > width + cloudWidth) {
                cloud.X = 0 - cloudWidth;
            }
            cloud.X += cloud.direction / 2;

        }
        cloud.draw();
    });

    platforms.forEach(function (platform, index) {
        if (platform.isMoving) {
            if (platform.X < 0) {
                platform.direction = 1; //right
            } else if (platform.X > width - platformWidth) {
                platform.direction = -1; //left
            }
            platform.X += platform.direction * (index / 2) * ~~((points / 100) % 8);
        }
        platform.draw();
    });
    mushrooms.forEach(function(mushroom, index) {
       mushroom.draw(); 
    });
    stats();

    checkCollision();
    player.update();
    if (state)
        gLoop = setTimeout(GameLoop, 1000 / 50); //ГЛАВНАЯ РЕКУРСИЯ
    else if (state == 2) StartMenu();
}

var StartMenu = function () {
    clear();

    ctx.fillStyle = "#7bb3ff";
    if (select == 0)
        ctx.fillRect(0, height / (3), width, height / 6);
    else
        ctx.fillRect(0, height / (3) + height / 6, width, height / 6);

    if (fontsReady == true) {
        ctx.font = '14px "Press Start 2P"';
        ctx.fillStyle = "#ffffff";
        ctx.textBaseline = "center";
        ctx.textAlign = "center";
        ctx.fillText("Jamp*", width / 2, height / 4);
        ctx.fillText("Play", width / 2, height / (3 / 1.25));
        ctx.fillText("Exit", width / 2, height / (3 / 1.25) + height / 6);
    }
    if (state == 2)
        gLoop = setTimeout(StartMenu, 1000 / 50);
    else {
        clearTimeout();
        GameLoop();
    }
}