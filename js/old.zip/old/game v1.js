var canvas = document.getElementById("canvas"),
    ctx = canvas.getContext("2d"); //Canvas имеет метод getContext, который используется для получения контекста отображения. Контекст — это объект, вызывая методы которого, вы взаимодействуете с canvas API. 
var width = window.innerWidth,
    height = window.innerHeight;
var background = '#6b8cff';

canvas.width = width;
canvas.height = height;

var clear = function () {
    ctx.fillStyle = background;
    ctx.beginPath();
    ctx.rect(0, 0, width, height);
    ctx.closePath();
    ctx.fill();
}

var player = new(function () {
    var that = this;

    this.image = new Image();
    this.image.src = "img/hero.png";

    this.width = 32;
    this.height = 32;

    this.X = width / 2;
    this.Y = height / 2;

    this.setPosition = function (x, y) {
        this.X = x;
        this.Y = y;
    }

    this.jump = function () {
        if (!this.isJumping && !this.isFalling) {
            this.fallSpeed = 0;
            this.isJumping = true;
            this.jumpSpeed = 22;
        }
    }

    this.checkJump = function () {
    }

    this.checkFall = function () {}

    this.fallStop = function () {}

    this.moveLeft = function () {}

    this.moveRight = function () {}

    this.draw = function () {
        try {
            ctx.drawImage(that.image, 0, 0, that.width, that.height,
                that.X, that.Y, that.width, that.height);
        } catch (e) {}
    }

    this.update = function () {
        this.draw();
    }

})();


var Platform = function (x, y) {
    this.image = new Image();
    this.image.src = "img/block.png";

    this.width = 96;
    this.height = 32;

    this.onCollide = function () {}

    this.isMoving = ~~(Math.random() * 2); //~~ Округляет число
    this.direction = ~~(Math.random() * 2) ? -1 : 1;

    this.draw = function () {}

    this.X = ~~x;
    this.Y = y;

    return this;
}

var numberOfPlatforms = 7,
    platforms = [],
    platformWidth = 96,
    platformHeight = 32;

var generatePlatforms = function () {
    var position = 0;
    for (var i = 0; i < numberOfPlatforms; i++) {
        platforms[i] = new Platform((Math.random() * (width - platformWidth)), position);
    }
}();

var checkCollision = function () {

}

var GameOver = function () {
    clearTimeout(gLoop);
    GameLoop();
}

document.onmousemove = function (e) {
    if (player.X + canvas.offsetLeft > e.pageX - 20) {
        player.moveLeft(e.pageX - canvas.offsetLeft);
    } else if (player.X + canvas.offsetLeft < e.pageX - 20) {
        player.moveRight(e.pageX - canvas.offsetLeft);
    }
}

player.setPosition(~~((width - player.width) / 2), ~~((height - player.height) / 2));
player.jump();

var GameLoop = function () {
    clear();
    checkCollision();
    player.update();
    var gLoop = setTimeout(GameLoop, 1000 / 60); //ГЛАВНАЯ РЕКУРСИЯ
}

window.onload = function () {
    GameLoop();
}